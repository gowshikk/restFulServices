package com.cognizant.day2Session4REST.day2Session4REST;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Day2Session4RestApplicationTests {

	@Test
	void contextLoads() {
	}

}
