package com.cognizant.day2Session4REST.day2Session4REST;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Day2Session4RestApplication {

	public static void main(String[] args) {
		SpringApplication.run(Day2Session4RestApplication.class, args);
	}

}
