package com.cognizant.day2Session4REST.day2Session4REST;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;

@ControllerAdvice
public class CountryExceptionHandler {

	@ResponseStatus(value = HttpStatus.NOT_FOUND)
    @ExceptionHandler({CountryNotFoundException.class})
    public String handle(CountryNotFoundException e) 
	{
		return e.getMessage();
	}
}
