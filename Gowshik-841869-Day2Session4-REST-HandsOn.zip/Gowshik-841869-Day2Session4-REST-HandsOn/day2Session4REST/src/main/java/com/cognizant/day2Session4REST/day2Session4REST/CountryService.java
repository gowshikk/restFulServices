package com.cognizant.day2Session4REST.day2Session4REST;

import java.util.ArrayList;

import org.springframework.stereotype.Service;


public class CountryService {

	public Country getCountry(ArrayList<Country> country , String code)
	{
		for (Country c : country) {
			if(c.getCode().equalsIgnoreCase(code))
			{
				return c;
			}
		}
		return null;
	}
	
	
}
