package com.cognizant.day2Session1Rest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Day2Session1RestApplication {

	public static void main(String[] args) {
		SpringApplication.run(Day2Session1RestApplication.class, args);
	}

}
