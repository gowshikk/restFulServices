package com.cognizant.day2Session1Rest;


public class Department {
	
	private String code;
	private String name;
	
	
	public Department() {
		
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public String toString() {
		return "Department [code=" + code + ", name=" + name + "]";
	}

	

}