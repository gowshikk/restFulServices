package com.cognizant.day2Session1Rest;
import java.util.ArrayList;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class DepartmentDAO {
	
	private static ArrayList<Department> departmentList;
	
	public ArrayList<Department> getAllDepartments() {
		ApplicationContext context = new ClassPathXmlApplicationContext("employee.xml");
		departmentList = context.getBean("departmentList", ArrayList.class);
		return departmentList;
	}
	
}