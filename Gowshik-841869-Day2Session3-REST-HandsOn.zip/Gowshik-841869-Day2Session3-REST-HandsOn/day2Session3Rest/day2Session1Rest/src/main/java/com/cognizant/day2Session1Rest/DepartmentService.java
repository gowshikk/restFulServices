package com.cognizant.day2Session1Rest;

import java.util.ArrayList;

import org.springframework.stereotype.Service;

@Service
public class DepartmentService {
	
	public ArrayList<Department> getAllDepartments() {
		DepartmentDAO departmentDAO = new DepartmentDAO();
		return departmentDAO.getAllDepartments();
	}
	
}