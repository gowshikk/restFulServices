package com.cognizant.day2Session1Rest;

import java.util.ArrayList;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
public class Controller {
	
	@GetMapping("/employees")
	public ArrayList<Employee> getAllEmployees()
	{
		EmployeeService employeeService = new EmployeeService();
		return employeeService.getAllEmployees();
	}
	
	@GetMapping("/departments")
	public ArrayList<Department> getAllDepartments() {
		DepartmentService departmentService = new DepartmentService();
		return departmentService.getAllDepartments();
	}
	
}
