package com.cognizant.day2Session1Rest;

import java.util.ArrayList;

import org.springframework.stereotype.Service;
@Service
public class EmployeeService {
	
	public ArrayList<Employee> getAllEmployees() {
		EmployeeDAO employeeDAO = new EmployeeDAO();
		return employeeDAO.getAllEmployees();
	}
	
}