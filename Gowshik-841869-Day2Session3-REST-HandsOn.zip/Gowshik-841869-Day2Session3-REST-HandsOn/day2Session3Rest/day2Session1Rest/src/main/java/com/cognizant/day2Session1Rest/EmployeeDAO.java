package com.cognizant.day2Session1Rest;
import java.util.ArrayList;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;


public class EmployeeDAO {
	

	private static ArrayList<Employee> employeeList;

	public ArrayList<Employee> getAllEmployees() {
		ApplicationContext context = new ClassPathXmlApplicationContext("employee.xml");
		employeeList = context.getBean("employeeList", ArrayList.class);
		return employeeList;
	}
	
}