package com.cognizant.day2Session1Rest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Day2Session1RestApplicationTests {

	@Test
	void contextLoads() {
	}

}
