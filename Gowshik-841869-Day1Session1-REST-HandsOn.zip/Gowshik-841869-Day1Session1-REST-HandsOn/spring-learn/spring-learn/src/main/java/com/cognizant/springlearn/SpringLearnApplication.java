package com.cognizant.springlearn;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

@SpringBootApplication
public class SpringLearnApplication {
	
	private static final Logger log = LoggerFactory.getLogger(SpringApplication.class);

	public static void main(String[] args) throws ParseException {
		SpringApplication.run(SpringLearnApplication.class, args);
		displayDate();
		displayCountry();
		displayCountries();
	}

	private static void displayCountries() {
		log.info("START displayCountries()");
		@SuppressWarnings("resource")
		ApplicationContext ctx = new ClassPathXmlApplicationContext("country.xml");
		@SuppressWarnings("unchecked")
		ArrayList<Country> list = (ArrayList<Country>) ctx.getBean("countryList");
		
		log.debug(list.toString());

		log.info("END  displayCountries()");
	}

	private static void displayCountry() {
		log.info("START  displayCountry()");
		@SuppressWarnings("resource")
		ApplicationContext ctx = new ClassPathXmlApplicationContext("country.xml");
		Country country = ctx.getBean("country" ,Country.class);
		
		log.debug(country.toString());
		//System.err.println(today);
		//log.info(country.toString());
		
		log.info("Setting scope to prototype.... Counstructor is called again");		
		// Setting scope to prototype
		Country anotherCountry = ctx.getBean("country", Country.class);
		log.debug(anotherCountry.toString());

		log.info("END  displayCountry()");
		
	}

	private static void displayDate() throws ParseException {

		log.info("START  displayDate()");
		@SuppressWarnings("resource")
		ApplicationContext ctx = new ClassPathXmlApplicationContext("date-format.xml");
		SimpleDateFormat format = ctx.getBean("dateFormat", SimpleDateFormat.class);
		
		Date today = format.parse("22/06/2020");
		log.debug(today.toString());
		//System.err.println(today);
		//log.info(today.toString());
		log.info("END  displayDate()");
	}

}
