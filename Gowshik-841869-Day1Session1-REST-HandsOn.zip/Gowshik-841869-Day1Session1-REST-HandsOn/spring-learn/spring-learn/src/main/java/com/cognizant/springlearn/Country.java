package com.cognizant.springlearn;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Country {

	private static final Logger log = LoggerFactory.getLogger(Country.class);

	private String code;
	private String name;
	public Country() {
		super();
		log.info("Inside Country Constructor");
	}
	public String getCode() {
		log.debug("Debuging in getCode()");
		return code;
	}
	public void setCode(String code) {
		log.debug("Debuging in setCode()");
		this.code = code;
	}
	public String getName() {
		log.debug("Debuging in getName()");
		return name;
	}
	public void setName(String name) {
		log.debug("Debuging in setName()");
		this.name = name;
	}
	@Override
	public String toString() {
		return "Country [code=" + code + ", name=" + name + "]";
	}
}
