package com.cognizant.springlearn;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class SpringLearnApplicationTests {

	

	@Test
	public void contextLoads() {
	}



}
