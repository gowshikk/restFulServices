package com.cognizant.springlearn.controller;

import java.util.ArrayList;

import com.cognizant.springlearn.Country;

public class CountryService {

	public Country getCountry(ArrayList<Country> country , String code)
	{
		for (Country c : country) {
			if(c.getCode().equalsIgnoreCase(code))
			{
				return c;
			}
		}
		return null;
	}
}
