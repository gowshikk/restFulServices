package com.cognizant.springlearn.controller;

import java.util.ArrayList;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import com.cognizant.springlearn.Country;

@RestController
public class CountryController {
	
	private static final Logger log = LoggerFactory.getLogger(CountryController.class);
	
	@GetMapping("/country")
	public  String getCountryIndia()
	{
		log.info("START of getCountryIndia() method");
		
		log.info("Fetching 'in' bean");
		@SuppressWarnings("resource")
		ApplicationContext ctx = new ClassPathXmlApplicationContext("country.xml");
		Country india = ctx.getBean("in" ,Country.class);
		log.info("Fetched");
		return india.toString();
		
	}
	
	
	@GetMapping("/country/{code}")
	@ResponseBody
	public  ResponseEntity<Country> getCountry(@PathVariable("code")String code)
	{
		log.info("START of getCountry() using code method");
		
		log.info("Fetching 'in' bean");
		@SuppressWarnings("resource")
		ApplicationContext ctx = new ClassPathXmlApplicationContext("country.xml");
		
	
		ArrayList<Country> list = (ArrayList<Country>) ctx.getBean("countryList");
		CountryService cs = new CountryService();
		Country ctry = cs.getCountry(list, code);
		if( ctry != null)
		{
			
			return ResponseEntity.ok(ctry);
		}
		else
		{
			//return ResponseEntity.notFound().build();
			throw new ResponseStatusException(HttpStatus.NOT_FOUND,"Country Not found");
		}
		
		
	}
	
	
	
	@GetMapping("/countries")
	public  String getAllCountry()
	{
		log.info("START of getAllCountry() method");
		
		log.info("Fetching all Country bean");
		@SuppressWarnings("resource")
		ApplicationContext ctx = new ClassPathXmlApplicationContext("country.xml");
		@SuppressWarnings("unchecked")
		ArrayList<Country> list = (ArrayList<Country>) ctx.getBean("countryList");
		log.info("Fetched");
		return list.toString();
		
	}
}
