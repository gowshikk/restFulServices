package com.cognizant.springlearn.controller;

import java.text.ParseException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ControllerApplication {
	
	private static final Logger log = LoggerFactory.getLogger(SpringApplication.class);

	public static void main(String[] args) throws ParseException {
		log.info("Starting the Controller Application on server port 8083");
		SpringApplication.run(ControllerApplication.class, args);
		log.info("End of the Controller Application on server port 8083");

		
	}

	
}
