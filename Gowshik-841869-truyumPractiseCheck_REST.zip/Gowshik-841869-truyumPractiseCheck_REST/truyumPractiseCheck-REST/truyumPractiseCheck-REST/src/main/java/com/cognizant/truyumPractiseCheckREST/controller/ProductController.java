package com.cognizant.truyumPractiseCheckREST.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.cognizant.truyumPractiseCheckREST.product.Product;
import com.cognizant.truyumPractiseCheckREST.service.ProductService;



@RestController
@RequestMapping("/truyum")
public class ProductController {

	@Autowired
	ProductService productService;

	@GetMapping("/home")
	public ModelAndView showHomepage() {
		return new ModelAndView("home");
	}
	
	@GetMapping("/showAllProducts")
	@ResponseStatus(code = HttpStatus.FOUND)
	public List<Product> getAllProducts() {
		return productService.getAllProducts();
	}
	
	@GetMapping("/addProduct")
	public ModelAndView add() {
		return new ModelAndView("addproduct");
	}
	
	
	@PostMapping("/saveProduct")
	@ResponseStatus(code = HttpStatus.ACCEPTED)
	public Product addProduct(Product product) {
		return productService.save(product);
	}
	
	@GetMapping("/delete")
	public ModelAndView delete() {
		return new ModelAndView("deleteproduct");
	}
	
	@GetMapping("/deleteProduct/{id}")
	@ResponseStatus(code = HttpStatus.FOUND)
	public ModelAndView addProduct(@RequestParam(value = "id") Integer id) {
		productService.delete(id);
		return new ModelAndView("home");
		
	}
	
	
	
	
	@GetMapping("/findProduct")
	public ModelAndView find() {
		return new ModelAndView("findProduct");
	}


	@GetMapping("/findById/{id}")
	@ResponseStatus(code = HttpStatus.FOUND)
	public Product findById(@RequestParam(value = "id") Integer id) {
		return 	productService.findById(id);
	}
}
